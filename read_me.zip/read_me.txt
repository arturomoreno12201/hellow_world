HOW TO USE
----------

1. Open hellow_world.exe
2. ead
3. Press enter
4. Done


Credits
-------

Programmers, Arturo Moreno <arturo.moreno@aie.edu> and Benjamin Vongtawan <benjamin.vongtawan@aie.edu>